# Football Hub — API-powered upgrade

This version uses API-Football for player profile search and season statistics. It is a local development project; it is not yet published on Google or the public internet.

## 1. Get an API key
1. Visit https://www.api-football.com/ and open its dashboard.
2. Create an account and activate the Free plan (the provider currently lists 100 requests/day; free access has season/data limitations).
3. Copy your API key. Do not share it or paste it into the website's HTML.

## 2. Install and run on Windows
1. Install Python 3 if it is not already installed.
2. Extract this ZIP file.
3. Open the extracted `football_hub_upgrade` folder.
4. Click the folder address bar, type `cmd`, and press Enter.
5. Run:
   `py -m pip install -r requirements.txt`
6. Set your API key in that same Command Prompt window:
   `set APIFOOTBALL_KEY=PASTE_YOUR_KEY_HERE`
7. Start the website:
   `py app.py`
8. Open Chrome and visit:
   `http://127.0.0.1:5000`

## Notes
- The API key is read by the Python server, not exposed in the browser's page source.
- Search requires at least four characters.
- The API's player profile search and player statistics endpoints are used.
- The app loads statistics for the selected season (default 2025); choose another season in the profile.
- Player age comes from the provider's profile and is recalculated by the provider as its data is updated.
- Statistics are not guaranteed for every player, league, or season. "Worldwide" means as many competitions as the provider covers, not every footballer on Earth.
- The free plan currently lists 100 requests per day and limits available seasons. Check the provider's current plan and coverage before relying on it.
- Do not publish the API key in GitHub or any public code. A public deployment needs a secure server-side environment variable.
