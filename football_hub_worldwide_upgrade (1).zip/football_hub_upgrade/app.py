import os
import requests
from flask import Flask, jsonify, render_template, request

app = Flask(__name__)
API_BASE = "https://v3.football.api-sports.io"

def api_get(endpoint, params):
    key = os.getenv("APIFOOTBALL_KEY")
    if not key:
        return None, ("Football data API key is not set. Add APIFOOTBALL_KEY to your environment.", 503)
    try:
        response = requests.get(
            f"{API_BASE}/{endpoint}",
            headers={"x-apisports-key": key},
            params=params,
            timeout=20,
        )
        response.raise_for_status()
        data = response.json()
        if data.get("errors"):
            return None, (str(data["errors"]), 502)
        return data.get("response", []), None
    except requests.RequestException as exc:
        return None, (f"Football data provider request failed: {exc}", 502)
    except ValueError:
        return None, ("The football data provider returned an unreadable response.", 502)

@app.get("/")
def home():
    return render_template("index.html")

@app.get("/api/search")
def search_players():
    q = request.args.get("q", "").strip()
    if len(q) < 4:
        return jsonify({"error": "Enter at least 4 letters to search players."}), 400
    results, error = api_get("players/profiles", {"search": q})
    if error:
        return jsonify({"error": error[0]}), error[1]
    players = []
    for item in results or []:
        p = item.get("player", {})
        players.append({
            "id": p.get("id"),
            "name": p.get("name"),
            "age": p.get("age"),
            "nationality": p.get("nationality"),
            "photo": p.get("photo"),
            "birth": p.get("birth") or {},
        })
    return jsonify({"players": players})

@app.get("/api/player/<int:player_id>")
def player_details(player_id):
    season = request.args.get("season", "2026")
    if not season.isdigit() or len(season) != 4:
        return jsonify({"error": "Season must be a four-digit year, for example 2025."}), 400
    results, error = api_get("players", {"id": player_id, "season": season})
    if error:
        return jsonify({"error": error[0]}), error[1]
    if not results:
        return jsonify({"error": "No player statistics were found for that season."}), 404
    item = results[0]
    return jsonify(item)

if __name__ == "__main__":
    app.run(host="127.0.0.1", port=5000, debug=True)
